package com.csi.jpa;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Service {
	
	private static SessionFactory factory= new AnnotationConfiguration().configure().buildSessionFactory();
	
	
	public static void main(String[] args) {
	
		Session session=factory.openSession();
		
		Transaction transaction=session.beginTransaction();
		
		Address a1 = new Address("AMNORA MALL", "PUNE", "MH", "INDIA", 411028);
		
		session.save(a1);
		
		Employee e1 = new Employee("BINU", 9898.89, a1);
		session.save(e1);
		transaction.commit();

	}
}
